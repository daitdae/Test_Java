package Soccer_Player.vo;

public class Player {
 private int account_number;
 private String player_name;
 private double height;
 private double weight;
 private int back_number;
 private String nationality;
 private String player_birthday;
public Player() {
	super();
	// TODO Auto-generated constructor stub
}
public Player(int account_number, String player_name, double height, double weight, int back_number,
		String nationality, String player_birthday) {
	super();
	this.account_number = account_number;
	this.player_name = player_name;
	this.height = height;
	this.weight = weight;
	this.back_number = back_number;
	this.player_birthday=player_birthday;
	this.nationality = nationality;
}
public int getAccount_number() {
	return account_number;
}
public void setAccount_number(int account_number) {
	this.account_number = account_number;
}
public String getPlayer_name() {
	return player_name;
}
public void setPlayer_name(String player_name) {
	this.player_name = player_name;
}
public double getHeight() {
	return height;
}
public void setHeight(double height) {
	this.height = height;
}
public double getWeight() {
	return weight;
}
public void setWeight(double weight) {
	this.weight = weight;
}
public int getBack_number() {
	return back_number;
}
public void setBack_number(int back_number) {
	this.back_number = back_number;
}
public String getNationality() {
	return nationality;
}
public void setNationality(String nationality) {
	this.nationality = nationality;
}
public String getPlayer_birthday() {
	return player_birthday;
}
public void setPlayer_birthday(String player_birthday) {
	this.player_birthday=player_birthday;
}
@Override
public String toString() {
	return "Player [account_number=" + account_number + ", player_name=" + player_name + ", height=" + height
			+ ", weight=" + weight + ", back_number=" + back_number + ", nationality=" + nationality
			+ ", player_birthday=" + player_birthday + "]";
}


 
}
