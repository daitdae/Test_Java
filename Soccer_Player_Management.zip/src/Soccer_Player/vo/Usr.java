package Soccer_Player.vo;

public class Usr {
	private String usrid;
	private String usrname;
	private String gender;
	private String birhtdate;
	private String phone_number;
	private String agent;
	public Usr() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Usr(String usrid, String usrname, String gender, String birhtdate, String phone_number, String agent) {
		super();
		this.usrid = usrid;
		this.usrname=usrname;
		this.gender = gender;
		this.birhtdate = birhtdate;
		this.phone_number = phone_number;
		this.agent = agent;
	}
	public String getUsrid() {
		return usrid;
	}
	public void setUsrid(String usrid) {
		this.usrid = usrid;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirhtdate() {
		return birhtdate;
	}
	public void setBirhtdate(String birhtdate) {
		this.birhtdate = birhtdate;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public String getUsrname() {
		return usrname;
	}
	public void setUsrname(String usrname) {
		this.usrname = usrname;
	}
	@Override
	public String toString() {
		return "Usr [usrid=" + usrid + ", usrname=" + usrname + ", gender=" + gender + ", birhtdate=" + birhtdate
				+ ", phone_number=" + phone_number + ", agent=" + agent + "]";
	}


}
