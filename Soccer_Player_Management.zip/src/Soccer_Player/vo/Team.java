package Soccer_Player.vo;

public class Team {
	private int team_code;
	private String team_name;
	private String coach;
	private String location;
	private String estimate_date;
	public Team() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Team(int team_code, String team_name, String coach, String location, String estimate_date) {
		super();
		this.team_code = team_code;
		this.team_name = team_name;
		this.coach = coach;
		this.location = location;
		this.estimate_date = estimate_date;
	}
	public int getTeam_code() {
		return team_code;
	}
	public void setTeam_code(int team_code) {
		this.team_code = team_code;
	}
	public String getTeam_name() {
		return team_name;
	}
	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}
	public String getCoach() {
		return coach;
	}
	public void setCoach(String coach) {
		this.coach = coach;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEstimate_date() {
		return estimate_date;
	}
	public void setEstimate_date(String estimate_date) {
		this.estimate_date = estimate_date;
	}
	@Override
	public String toString() {
		return "Team [team_code=" + team_code + ", team_name=" + team_name + ", coach=" + coach + ", location="
				+ location + ", estimate_date=" + estimate_date + "]";
	}

}
