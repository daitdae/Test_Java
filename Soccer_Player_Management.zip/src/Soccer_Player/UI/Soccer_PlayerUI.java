package Soccer_Player.UI;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import Soccer_Player.Service.SoccerPlayerService;
import Soccer_Player.vo.Player;
import Soccer_Player.vo.Usr;

public class Soccer_PlayerUI {
	Scanner keyin = new Scanner(System.in);
	SoccerPlayerService service = new SoccerPlayerService();

	public Soccer_PlayerUI() {
		String choice;

		while (true) {
			System.out.println("1. 로그인");
			System.out.println("2. 회원가입");
			System.out.print("     >선 택: ");
			choice = keyin.next();
			switch (choice) {
			case "1":
				Login();
				break;
			case "2":
				join();
				break;
			case "0":
				System.out.println("종료");
				return;
			default:
				keyin.nextLine();
			}
		}
	}

	private void join() {
		String usrid;
		String usrname;
		String gender;
		String birthdate;
		String phone_number;
        String agent;
        
		System.out.println("회원가입");
		System.out.print("아이디 입력: ");
		usrid = keyin.next();
		
			
		Usr info = service.findUsr(usrid);
		if (info != null) {
			System.out.println("회원 정보 있음");
			return;
		}
		
		System.out.print("이름 입력: ");
		usrname = keyin.next();
		System.out.print("성별 입력: ");
		gender = keyin.next();
		System.out.print("생년월일: ");
		birthdate = keyin.next();
		System.out.print("전화번호: ");
		phone_number = keyin.next();
		System.out.print("agent 여부(y/n): ");
		agent = keyin.next();
	
	
		Usr u = new Usr(usrid, usrname, gender, birthdate, phone_number, agent);
		int result = service.join(u);
		if (result == 1) {
			System.out.println("가입 완료");
		} else
			System.out.println("가입 실패");
	}

	private void Login() {
		String usrid;
		String choice;
		String agent = null;

		System.out.println("로그인");
		System.out.print("아이디 입력: ");
		usrid = keyin.next();

		Usr info = service.findUsr(usrid);
		if (info == null) {
			System.out.println("회원 정보 없음");
			return;
		}

		Usr manager = service.findAgent(agent);
		if (agent.equals('y')) {
			while (true) {
				mainMenu();
				choice = keyin.next();
				switch (choice) {
				case "1":
					selectOne();
					break;
				case "2":
					selectAll();
					break;
				case "3":
					insertPlayer();
					break;
				case "4":
					deletePlayer();
					break;
				case "5":
					updatePlayer();
					break;
				case "0":
					System.out.println("종료");
					return;
				default:
					keyin.nextLine();
				}
			}
		} else {
			while (true) {
				System.out.println("1. 선수 정보 조회");
				System.out.println("2. 전체 선수 조회");
				System.out.print("     >선 택: ");
				choice = keyin.next();
				switch (choice) {
				case "1":
					selectOne();
					break;
				case "2":
					selectAll();
					break;
				case "0":
					System.out.println("종료");
					return;
				default:
					keyin.nextLine();
				}

			}
		}

	}

	private void selectOne() {
		String player_name = null;
		int account_number;

		System.out.println("    [선수 정보 조회]");
		System.out.print("    >선수 이름 :");
		account_number = keyin.nextInt();

		Player info = service.selectOne(player_name);

		if (info == null) {
			System.out.println("선수 정보 없음");
		}
		System.out.println(info);
	}

	private void selectAll() {
		System.out.println("    [전체 선수 조회]");
		List<Player> list = service.selectAll();
		if (list.size() == 0) {
			System.out.println("선수 정보 없음");
			return;
		}

		Iterator<Player> iter = list.iterator();

		while (iter.hasNext()) {
			System.out.println(iter.next());
		}
	}

	private void insertPlayer() {
		System.out.println("선수 등록");

		String player_name = null;
		int account_number;
		double height;
		double weight;
		int back_number;
		String player_birthday;
		String nationality;

		System.out.print("등록번호 입력: ");
		account_number = keyin.nextInt();

		Player info = service.find(account_number);
		if (info != null) {
			System.out.println("선수 정보 있음");
			return;
		}

		System.out.print("이름 입력: ");
		player_name = keyin.next();
		System.out.print("키 입력: ");
		height = keyin.nextDouble();
		System.out.print("무게입력: ");
		weight = keyin.nextDouble();
		System.out.print("등번호 입력: ");
		back_number = keyin.nextInt();
		System.out.print("선수 생일: ");
		player_birthday = keyin.next();
		System.out.print("선수 국적: ");
		nationality = keyin.next();

		Player p = new Player(account_number, player_name, height, weight, back_number, nationality, player_birthday);
		int result = service.insertPlayer(p);
		if (result == 1) {
			System.out.println("가입 완료");
		} else
			System.out.println("가입 실패");
	}

	private void updatePlayer() {
		int account_number;
		double height;
		double weight;
		int back_number;
		
		System.out.print("선수 등록번호 조회 :");
		account_number = keyin.nextInt();
		Player p = service.find(account_number);
		if (p == null) {
			System.out.println("선수 정보 없음");
			return;
		}
		System.out.println(p);
		
		System.out.print("키 입력: ");
		height = keyin.nextDouble();
		System.out.print("무게입력: ");
		weight = keyin.nextDouble();
		System.out.print("등번호 입력: ");
		back_number = keyin.nextInt();
		
		Player player = new Player(account_number, null, height, weight, back_number, null, null);
		int result = service.insertPlayer(p);
		if (result == 1) {
			System.out.println("가입 완료");
		} else
			System.out.println("가입 실패");
	}

	private void deletePlayer() {
		String player_name;
		String answer;
		int account_number;

		System.out.print("선수 등록번호 조회 :");
		account_number = keyin.nextInt();
		Player p = service.find(account_number);
		if (p == null) {
			System.out.println("선수 정보 없음");
			return;
		}
		System.out.println(p);
		System.out.print("정말로 삭제? (y/n) :");
		answer = keyin.next();
		if (answer.equals("y")) {
			int result = service.deletePlayer(account_number);
			System.out.println("삭제 완료");
		} else
			System.out.println("삭제 취소");
	}

	private void mainMenu() {
		System.out.println("==[회원 정보 관리]==");
		System.out.println("1. 선수 정보 조회");
		System.out.println("2. 전체 선수 조회");
		System.out.println("3. 선수 정보 등록");
		System.out.println("4. 선수 정보 삭제");
		System.out.println("5. 선수 정보 수정");
		System.out.println("0. 종료");
		System.out.println("================");
		System.out.print("     >선 택: ");

	}

}