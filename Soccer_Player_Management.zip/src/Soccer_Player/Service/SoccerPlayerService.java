package Soccer_Player.Service;

import java.util.List;

import Soccer_Player.DAO.Soccer_PlayerDAO;
import Soccer_Player.vo.Player;
import Soccer_Player.vo.Usr;



public class SoccerPlayerService {
	Soccer_PlayerDAO dao = new Soccer_PlayerDAO();
	
	public int join(Usr usrid) {
		int result= dao.join(usrid);
		return result;
	}
	public int insertPlayer(Player player) {
		int result=dao.insertPlayer(player);
		return result;
	}
	public int deletePlayer(int account_number) {
		int result = dao.deletePlayer(account_number);
		return result;
	}
	public int updatePlayer(Player player) {
		int result =dao.updatePlayer(player);
		return result;
	}
	public List<Player> selectAll() {
		List<Player> list = dao.selectAll();
		return  list;
	}
	public Player selectOne(String player_name) {
		Player info = dao.selectOne(player_name);
		return info;
	}
	public Usr findAgent(String agent) {
		Usr result = dao.findAgent(agent);
		return result;
	}
	public Usr findUsr(String usrid) {
		Usr info = dao.findUsr(usrid);
		return info;
	}
	public Player find(int account_number) {
		Player info = dao.find(account_number);
		return info;
	}

}
