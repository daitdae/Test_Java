package Soccer_Player.DAO;

import java.util.List;

import Soccer_Player.vo.Player;
import Soccer_Player.vo.Team;
import Soccer_Player.vo.Usr;

public interface Soccer_PlayerMapper {
	
	public int join(Usr usrid);
	public int insertPlayer(Player player);
	public List<Player> selectAll();
	public Player selectOne(String player_name);
	public int updatePlayer(Player player);
	public int deletePlayer(int account_number);
	public Usr findAgent(String agent);
	public Usr findUsr(String usrid);
	public Player find(int account_number);
	

}
