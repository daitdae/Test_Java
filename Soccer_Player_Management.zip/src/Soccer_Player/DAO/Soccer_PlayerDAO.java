package Soccer_Player.DAO;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import Soccer_Player.vo.Player;
import Soccer_Player.vo.Usr;


public class Soccer_PlayerDAO {
	SqlSessionFactory factory= MybatisConfig.getSessionFactory();
	
	public int join(Usr usrid) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		int result=mapper.join(usrid);
		return result;
	}
	
	public List<Player> selectAll(){
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		List<Player> list = mapper.selectAll();
		return list;
	}
	public Player selectOne(String player_name) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		Player member = mapper.selectOne(player_name);
		return member;
	}
	
	public int insertPlayer(Player player) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		int result=mapper.insertPlayer(player);
		session.commit();
		return result;
		
	}
	
	public int updatePlayer(Player player) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		int result=mapper.updatePlayer(player);
		session.commit();
		return result;
	}
	public int deletePlayer(int account_number) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		int result=mapper.deletePlayer(account_number);
		session.commit();
		return result;
	}
	public Usr findAgent(String agent) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		Usr result = mapper.findAgent(agent);
		return result;
		
	}

	public Usr findUsr(String usrid) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		Usr member = mapper.findUsr(usrid);
		return member;
	}

	public Player find(int account_number) {
		SqlSession session = null;
		session=factory.openSession();
		Soccer_PlayerMapper mapper = session.getMapper(Soccer_PlayerMapper.class);
		Player member = mapper.find(account_number);
		return member;
		
	}

	
}
