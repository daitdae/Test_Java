package Soccer_Player.Main;

import Soccer_Player.UI.Soccer_PlayerUI;

public class Soccer_playerMain {

	public static void main(String[] args) {
		new Soccer_PlayerUI();

	}

}
