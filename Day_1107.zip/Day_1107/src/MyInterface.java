
public interface MyInterface {
	int DATA = 25;
	public static final String NAME = "서울"; // 이게 완벽한 표현 위에는 public s f 가 생략 된것
	
	public int methodA(int a, int b);
	public int methodB(int a, int b);
}
