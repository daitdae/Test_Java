
public class MyClass_2 implements MyInterface {

	@Override
	public int methodA(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int methodB(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

}
