
public interface YourInterface {
	public int methodA(int a, int b);
	public int methodC(int a, int b);
	

}
