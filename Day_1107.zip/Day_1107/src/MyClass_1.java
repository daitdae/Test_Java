
public class MyClass_1 implements MyInterface {
	
	@Override
	public int methodA(int a, int b) {
		return 0;
	}
	@Override
	public int methodB(int a, int b) {
		return 1;
	}
	
	public static void main(String[] args) {
		
		
	}

}
