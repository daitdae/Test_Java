
public class MyClass_3 implements MyInterface, YourInterface {

	@Override
	public int methodC(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int methodA(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int methodB(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

}
