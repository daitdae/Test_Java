package global.sesoc.polygon;

public interface Calc {
	public double area();
	
}
