
public class GymMain {

	public static void main(String[] args) {
		
		GymService service = new GymService();
			
		
		
		

	}

}
